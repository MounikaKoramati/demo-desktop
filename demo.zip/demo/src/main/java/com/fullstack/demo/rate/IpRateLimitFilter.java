package com.fullstack.demo.rate;

public class IpRateLimitFilter {
    
}
