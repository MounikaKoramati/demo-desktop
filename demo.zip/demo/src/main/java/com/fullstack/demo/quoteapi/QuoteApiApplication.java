package com.fullstack.demo.quoteapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class QuoteApiApplication {
    public static void main(String[]args){
        SpringApplication.run(QuoteApiApplication.class,args)
    }
}
