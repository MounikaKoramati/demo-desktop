package com.fullstack.demo.config;

public class OpenApiConfig {
    
}
