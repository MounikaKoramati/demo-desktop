package com.fullstack.demo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;
import java.util.Random;
public class QuoteController {
    private static final List<String>QUOTES=List.of("the only way to do great work is to love what you do -save jobs",
    "Wheather you think you can or you think you can't you're right - Henry ford","Success is not final failyre is not fatal it is the courage to continue that counts -Winston Churchill","Do one thing every day that scares you Eleanor Roosevelt", "Dream big and dare to fail -Norman Vaughan"
    
    );
    private final Random random =new Random();
    @GetMapping("/api/quote")
    public ResponseEntity<Map<String,String>>
    getRandomQuote(){
        String q=QUOTES.get(random.nextInt(QUOTES.size()));
        return ResponseEntity.ok(Map.of("quote",q));
    }
}
